Hi there!

Thank you for trying out R0xitto. This game is based on R0x on the Ouya and Atari ST! (Do check them out as they're amazing!)

Information:
This game is an Avoid-em-up type shooter. You start with a max of 9 bullets and 0 bombs. Shooting enemies, bosses and shuttles (the pink passive transporters) all drop items. The ORANGE item gives you +2 bullets (max 9 in total), the BLUE one gives you 1 bomb and the GREEN one gives you full health!

Collect crystals and spacemen for bonus points. Avoid asteroids where possible. Your hit box is in the middle of your ship and only 10 pixels wide and high, so it�s fairly easy to manoeuvre between asteroids and bullets etc. However, it also makes it a bit more of a challenge to collect items! Shuttles and enemies take 1 bullet to die. Bosses take 2 bullets to die. When playing in Arcade mode, the game is over when you run out of health. (Tip: use your ship to bash into a shuttle for a chance to collect a dropped item, at the expense of one health point). In survival mode, one hit and you�re dead.

The game saves the highscore on the real Pokitto.
To listen to the included music, ensure you have an SD card in your Pokitto and it has a folder called "music" and the song called �rox.wav� in. If the song gets annoying fast, I apologise. I quickly threw together something on my new xmas gift I got from the wife (Korg Volca Sample). You can always eject your SD card or replace it with a song of your choice with the same filename.

Credits:
Code, graphics, sfx, music - all by Jaco van der Walt.

If you like this game, please let us know! More of our games can be found at http://blackjet.co.uk - this game was made during November 2019 to 6th January 2020.

Thanks for playing!

Regards,
Jaco